package com.jonerds.ballanweather.data;

public interface DataManager {
}
