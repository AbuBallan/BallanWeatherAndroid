package com.jonerds.ballanweather.data.api;

public interface ApiHelper {
}
